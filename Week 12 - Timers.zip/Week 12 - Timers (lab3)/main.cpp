#include "mbed.h"

Ticker ticker;
int i = 0;

void print_incrementing_int() {
	printf("%d \r\n", i++);
}

int main() {
	ticker.attach(&print_incrementing_int, 0.5);
	while(1);
}
