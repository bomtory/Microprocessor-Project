#include "mbed.h"

Timeout timeout;

void print_the_message() {
	printf("Finished!");
}

int main() {
	timeout.attach(&print_the_message, 3.0);
	printf("Waiting for the delay.. \r\n");
	wait(0.95);
	printf("1 \r\n");
	wait(0.95);
	printf("2 \r\n");
	wait(0.95);
	printf("3 \r\n");
	while(1);
}
