#include "mbed.h"
#include "motordriver.h"

InterruptIn button1(PA_14);
InterruptIn button2(PB_7);
InterruptIn button3(PC_4);
Timer debounce_timer;
Serial pc(USBTX, USBRX);
Motor A(D11, PC_8);

int direction = 1;
float speed = 0.1;

void print_current_state() {
	pc.printf("Current State:\r\n");
	pc.printf("direction: %d\r\n", direction);
	pc.printf("speed: %3.1f\r\n\n", speed);
}
	
void change_direction() {
	if(debounce_timer.read() > 0.2) {
		direction = !direction;
		pc.printf("Change Rotation Direction to %d\r\n", direction);
		print_current_state();
		debounce_timer.reset();
	}
}

void acc() {
	if(debounce_timer.read() > 0.2) {
		if(speed < 1) {
			speed += 0.1;
			pc.printf("Increase Speed to %3.1f\r\n", speed);
		} else {
			pc.printf("Reached MAX Speed (No Increase)\r\n");
		}
		print_current_state();
		debounce_timer.reset();
	}
}

void dec() {
	if(debounce_timer.read() > 0.2) {
		if(speed > 0.2) {
			speed -= 0.1;
			pc.printf("Decrease Speed to %3.1f\r\n", speed);
		} else {
			pc.printf("Reached MIN Speed (No Decrease)\r\n");
		}
		print_current_state();
		debounce_timer.reset();
	}
}

int main() {
	print_current_state();
	button1.fall(&change_direction);
	button2.fall(&acc);
	button3.fall(&dec);
	debounce_timer.start();
	A.forward(speed);
	while(1) {
		if(direction == 1) {
			A.forward(speed);
		} else{
			A.backward(speed);
		}
	}
}
